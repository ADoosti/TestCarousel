export class Slide {
   Thumbnail: string ;
    Image: string;
}
